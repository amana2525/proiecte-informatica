/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>

using namespace std;
int main()
{ int a,b;
cout<<"a="; cin>>a;
cout<<"b="; cin>>b;
if(a>b)
cout<<"a "<<a-b;
else
cout<<"b "<<b-a;
  return 0;
}
