/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>

using namespace std;
int main()
{ int n;
    cin >> n;
    if(n == 1)
        cout << "ianuarie";
    if(n == 2)
        cout << "februarie";
    if(n == 3)
        cout << "martie";
    if(n == 4)
        cout << "aprilie";
    if(n == 5)
        cout << "mai";
    if(n == 6)
        cout << "iunie";
    if(n == 7)
        cout << "iulie";
    if(n == 8)
        cout << "august";
    if(n == 9)
        cout << "septembrie";
    if(n == 10)
        cout << "octombrie";
    if(n == 11)
        cout << "noiembrie";
    if(n == 12)
        cout << "decembrie";
    return 0;

}
