/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>

using namespace std;
int main()
{ int x,a,b;
cin>>x>>a>>b;
if(a<=x && x<=b)
cout<<"DA";
else
cout<<"NU";
    return 0;

}
