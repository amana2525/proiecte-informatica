/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>

using namespace std;
int main()
{ int a,b,c,d;
cin>>a>>b>>c>>d;
while(a<=100)
if(a/b=c/d)
cout "da";
else
a++; b++;
 
    return 0;

}
