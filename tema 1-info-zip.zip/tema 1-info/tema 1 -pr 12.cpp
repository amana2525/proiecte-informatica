/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>

using namespace std;
int main()
{ int F,B,n;
cout<<"F="; cin>>F;
cout<<"B="; cin>>B;
cout<<"n=";cin>>n;

cout<<(3*F+2*B)*n;

 
    return 0;

}
