#include <iostream>

using namespace std;

int main()
{
    int n,V,C;
    cin>>n>>V>>C;
    cout<<(n*V/C)+1<<" camioane";
    return 0;
}
