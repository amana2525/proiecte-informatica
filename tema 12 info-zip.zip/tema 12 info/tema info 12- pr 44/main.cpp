#include <iostream>

using namespace std;

int main()
{
    int n, a=0, min=0, min=1;
    cout<<"n="; cin>>n;
    int n1=n;
    while(n!=a)
    {

    }
}
