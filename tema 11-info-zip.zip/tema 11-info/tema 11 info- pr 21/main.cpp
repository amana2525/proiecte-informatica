#include <iostream>

using namespace std;

int main()
{
    int n,d;
    cin>>n;
    for(d=1;d*d<=n;++d)
    {cout<<d*d<<" ";
    }
    return 0;
}
